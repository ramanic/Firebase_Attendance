package com.ramanic.attendance;



public class Teachers {
    String name, pass, sub,id;

    public Teachers() {
    }
    public String getName() {
        return name;
    }
    public String getid() {
        return id;
    }
    public void setid(String id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPass() {
        return pass;
    }
    public void setPass(String pass) {
        this.pass = pass;
    }
    public String getSub() {
        return sub;
    }
    public void setub(String sub) {
        this.sub = sub;
    }
}